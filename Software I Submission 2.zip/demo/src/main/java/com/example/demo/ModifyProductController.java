package com.example.demo;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

 /**
    RUNTIME ERROR - An error I experienced with this controller was I wasn't able to pull the sample information for the related parts table.
    To fix this, I double-checked my textfields to ensure that the names I had placed in were the same as the ones I named in the fxml, but I had not matched the names and that is why I was getting this error.
    After I changed the labels to make sure they were all matching the table populated the product information.

    FUTURE ENHANCEMENT - To enhance this product in the future, the best thing to do would be give the user the option to change an associated part to the same part from a different source.
    For example, if there is an option to use a bike wheel that is better quality than the standard bike wheel, and a customer orders a bike with bigger tires using the Modify Product form would enhance the application to different part options for the same product.
     */
/** this is where you will modify the products in inventory. */
public class ModifyProductController implements Initializable {


    public TextField SearchPartNameTxt;
    private static int selectedIndex;
    public TextField ProductIDTxt;
    public TextField ProductNameTxt;
    public TextField ProductInvCountTxt;
    public TextField ProductPriceTxt;
    public TextField ProdMaxHoldTxt;
    public TextField ProdMinHoldTxt;
    public TableColumn ProductIDColumn;
    public TableColumn ProductNameColumn;
    public TableColumn ProductInvLevelColumn;
    public TableColumn ProductPriceColumn;
    public TableColumn PartPriceColumn;
    public TableColumn PartInvLevelColumn;
    public TableColumn PartNameColumn;
    public TableColumn PartIDColumn;
    public TableView relatedPartsTable;
    public TableView<Part> allPartsTable;
    public TextField searchPartNameTxt;
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    private ObservableList<Part> bottomTableParts = FXCollections.observableArrayList();

    /**
     This will remove a part associated to a product.*/
    public void onRemoveAssociatedPart(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Do you want to remove this part?");
        alert.setHeaderText("Remove");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
        Part SP = (Part) relatedPartsTable.getSelectionModel().getSelectedItem();
           // relatedPartsTable.setItems(associatedParts);
        if (SP == null)
            return;
        associatedParts.remove(SP);
        //allParts.add(SP);
       relatedPartsTable.setItems(associatedParts);
    }
    }
/**
 This will cancel the action and take the user back to the main screen*/
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

/**
 This will save the information to the application. */
    public void onSave(ActionEvent actionEvent) throws IOException {
        try {
            int id = Inventory.incrementProductID();
            String name = String.valueOf(ProductNameTxt.getText());
            double price = Double.parseDouble(ProductPriceTxt.getText());
            int stock = Integer.parseInt(ProductInvCountTxt.getText());
            int min = Integer.parseInt(ProdMinHoldTxt.getText());
            int max = Integer.parseInt(ProdMaxHoldTxt.getText());

            //bottomTableParts = Product.getAllAssociatedParts();
            bottomTableParts.addAll(associatedParts);

            if (stock>max){
                System.out.println("Stock must be lower than Maximum Inventory!");
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error");
                alert1.setHeaderText(null);
                alert1.setContentText("Stock must be lower than Maximum Inventory!");
                alert1.showAndWait();
                return;
            }

            if (stock<min){
                System.out.println("Stock must be higher than Minimum Inventory!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Stock must be higher than Minimum Inventory!");

                alert.showAndWait();
                return;
            }
            if (name.isBlank()) {
                System.out.println("Name Value is blank");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please enter valid values!");

                alert.showAndWait();

            }
            Product product = new Product(id, name, price, stock, min, max);
            product.getAllAssociatedParts().clear();
            product.getAllAssociatedParts().addAll(associatedParts);
            Inventory.updateProduct(selectedIndex, product);

            Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Inventory Management System");
            stage.setScene(scene);
            stage.show();
        }
        catch (NumberFormatException e){
            System.out.println("Please enter valid values!");
            System.out.println("Please enter number values in number fields!");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please enter number values in number fields!");

            alert.showAndWait();
        }
    }

     /**
      This will add a part to the associated parts table. */

    public void onAdd(ActionEvent actionEvent) {
       Part SP = allPartsTable.getSelectionModel().getSelectedItem();
        if (SP == null)
            return;
        allParts.remove(SP);
        associatedParts.add(SP);
        relatedPartsTable.setItems(associatedParts);
    }
     /**
      This will search for a name or ID.
      */
    public void onSearch(ActionEvent actionEvent) {
        String q = searchPartNameTxt.getText();

        ObservableList<Part> parts = searchPartName(q);

        if (parts.size() == 0) {
            try {
                int id = Integer.parseInt(q);
                Part p = getAPartWithID(id);
                if (p != null)
                    parts.add(p);}
            catch (NumberFormatException e){}

        }
        allPartsTable.setItems(parts);
        searchPartNameTxt.setText("");
    }

    private ObservableList<Part> searchPartName(String partialName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (Part p : allParts) {
            if (p.getName().contains(partialName)) {
                namedParts.add(p);
            }
        }
        return namedParts;
    }
    private Part getAPartWithID(int id){
        ObservableList<Part> allParts = Inventory.getAllParts();

        for (int i=0; i < allParts.size(); i++ ){
            Part p = allParts.get(i);

            if (p.getId() == id){
                return p;
            }
        }

        return null;
    }

    /**
     * This is used to send the information between the main screen controller and the modify part controller. */
    public void sendProduct (Product product){
        selectedIndex = Inventory.getAllProducts().indexOf(product);
        ProductIDTxt.setText(String.valueOf(product.getId()));
        ProductNameTxt.setText(product.getName());
        ProductPriceTxt.setText(String.valueOf(product.getPrice()));
        ProductInvCountTxt.setText(String.valueOf(product.getStock()));
        ProdMinHoldTxt.setText(String.valueOf(product.getMin()));
        ProdMaxHoldTxt.setText(String.valueOf(product.getMax()));
        relatedPartsTable.setItems(product.getAllAssociatedParts());
        associatedParts.setAll(product.getAllAssociatedParts());

    }

    /**
     This is what the compiler will call to start up this page on the application. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am Initialized!");
        relatedPartsTable.setItems(associatedParts);
        allPartsTable.setItems(Inventory.getAllParts());
        PartIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        PartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        PartInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        PartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        ProductIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProductInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProductPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

    }


}
