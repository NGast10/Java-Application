package com.example.demo;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** RUNTIME ERROR - When I first started coding this page, I was not able to change my data type between String and int for the selections of either InHouse or Outsourced.
    All of my labels were set up correctly, but when I clicked my radio buttons the data type wouldn't change, which prevented me from moving on to verify data.
    I realized it was a logical error because I only needed the data type to change if a certain radio button was selected, this helped me realize what needed to be done to fix my app from not working.
    To fix this I added two if statements which changed the data type depending on which radio button was selected.

    *FUTURE ENHANCEMENT - To enhance this should it be updated in the future, I think the best way to enhance this would be to expand the capabilities for Adding parts to include more in-depth pricing informetion.
    By more in-depth, there could be information about how the InHouse parts are produced and how much they cost to produce.
    For the Outsourced parts it could be expanded to include information about the part and potential for the company to switch to a different provider for the part.
    *
    * */


/** This class is where you can add a part to the inventory class. */
public class AddPartController implements Initializable {
    public TextField PartIDTxt;
    public TextField PartMaxTxt;
    public TextField PartPriceTxt;
    public TextField PartInvTxt;
    public TextField PartNameTxt;
    public TextField PartMachineIDTxt;
    public TextField PartMinTxt;
    public Label machinesCompanyLabel;
    public RadioButton InHouse1;
    public ToggleGroup sourceTG;
    public RadioButton Outsourced1;

    /**
     This will cancel the action and take the user back to the main screen*/
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }
    /**
     This will save the information to the application. */
    public void onSave(ActionEvent actionEvent) throws IOException {
        try
        {
            // int id = Integer.parseInt(PartIDTxt.getText());
            int id = Inventory.incrementPartID();
            String name = String.valueOf(PartNameTxt.getText());
            double price = Double.parseDouble(PartPriceTxt.getText());
            int stock = Integer.parseInt(PartInvTxt.getText());
            int min = Integer.parseInt(PartMinTxt.getText());
            int max = Integer.parseInt(PartMaxTxt.getText());
            //int machineID = Integer.parseInt(PartMachineIDTxt.getText());
            //String CompanyName = String.valueOf(Integer.parseInt(PartMachineIDTxt.getText()));
            System.out.println("Test 1");

            if (stock>max){
                System.out.println("Stock must be lower than Maximum Inventory!");
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error");
                alert1.setHeaderText(null);
                alert1.setContentText("Stock must be lower than Maximum Inventory!");
                alert1.showAndWait();
                return;
            }

            if (stock<min){
                System.out.println("Stock must be higher than Minimum Inventory!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Stock must be higher than Minimum Inventory!");

                alert.showAndWait();
                return;
            }
            if (name.isBlank()) {
                System.out.println("Name Value is blank");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please enter valid values!");

                alert.showAndWait();

            }



            if (InHouse1.isSelected()) {
                System.out.println("Test 2");
                int machineID= Integer.parseInt(PartMachineIDTxt.getText());
                Part part = new InHouse(id,name,price,stock,min,max,machineID);
                Inventory.addPart(part);
                Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
                Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
                stage.setScene(scene);
                stage.show();
                System.out.println("Test 2");
            }
            if (Outsourced1.isSelected()) {
                System.out.println("Test 3");
                //CompanyName = PartMachineIDTxt.getText();
                String CompanyName = String.valueOf((PartMachineIDTxt.getText()));
                Part part = new Outsourced(id,name,price,stock,min,max,CompanyName);
                Inventory.addPart(part);
                Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
                Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
                Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
                stage.setScene(scene);
                stage.show();
                System.out.println("Test 3");
            }

        }
        catch (NumberFormatException e){
            System.out.println("Please enter number values in number fields!");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please enter number values in number fields!");

            alert.showAndWait();

        }


    }
    /**
     This will let the application know whether it's an InHouse or Outsourced part. */
    public void onInhouse(ActionEvent actionEvent) {
        machinesCompanyLabel.setText("Machine ID");
    }
    /**
     This will let the application know whether it's an InHouse or Outsourced part. */
    public void onOutsourced(ActionEvent actionEvent) {
        machinesCompanyLabel.setText("Company Name");
    }

    /**
     This is what the compiler will call to start up this page on the application. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am Initialized!");
    }
}
