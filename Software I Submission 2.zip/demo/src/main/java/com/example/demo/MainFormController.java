package com.example.demo;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
//import static javafx.swing.JOptionPane.showMessageDialog;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.util.Optional;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.Node;

 /**
  RUNTIME ERROR - An error I would receive is when I would click modify part or product without first selecting a part or product from the table, the application would crash.
  To fix this, I had to create a try/catch block for the NumberFormatException which would print out a line that says an item must be selected.
  FUTURE ENHANCEMENT - I believe this could be updated to show more information about the sales and performance of parts and products in graphs which have additional fxml documents which direct the user into a further breakdown of the sales analytics.
     */
/** This is the first method to initialize when running the code. */
public class MainFormController implements Initializable {

    Stage stage;
    Parent scene;
/**This is where you can search through the product table. */
    public TextField searchProductNameTxt;
    /** This method sets the product price column data type.*/
    public TableColumn<Product, Double> productPriceColumn;
    /** This method lets the program know the productsTable is from the Product class.*/
    public TableView<Product> productsTable;
    /** This method sets the product price id data type.*/
    public TableColumn<Product, Integer> productIDColumn;
    /** This method sets the product name column data type.*/
    public TableColumn<Product, String> productNameColumn;
    /** This method sets the product stock column data type.*/
    public TableColumn<Product,Integer> productInvLevelColumn;
    /** This method lets the program know the productsTable is from the Product class.*/
    public TableView<Part> partsTable;
    /** This method sets the part id column data type.*/

    public TableColumn<Part, Integer> partIDColumn;
    /** This method sets the part name column data type.*/
    public TableColumn<Part, String> partNameColumn;
    /** This method sets the part stock column data type.*/
    public TableColumn<Part, Integer> partInvLevelColumn;
    /** This method sets the part price column data type.*/
    public TableColumn<Part, Double> partPriceColumn;
    /** This method is where you can search the parts table. */
    public TextField searchPartNameTxt;

    /**
     This will search the product table either for a name or ID.
     */
    public void onSearchProduct(ActionEvent actionEvent) {
    String q = searchProductNameTxt.getText();

        ObservableList<Product> products = searchProductName(q);

        if (products.size() == 0) {
            try {
                int id = Integer.parseInt(q);
                Product p = getAProductWithID(id);
                if (p != null)
                    products.add(p);}
            catch (NumberFormatException e){}

        }
        productsTable.setItems(products);
        searchProductNameTxt.setText("");
    }

    private ObservableList<Product> searchProductName(String partialName) {
        ObservableList<Product> namedProducts = FXCollections.observableArrayList();

        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (Product p : allProducts) {
            if (p.getName().contains(partialName)) {
                namedProducts.add(p);
            }
        }
        return namedProducts;
    }
    private Product getAProductWithID(int id){
        ObservableList<Product> allProducts = Inventory.getAllProducts();

        for (int i=0; i < allProducts.size(); i++ ){
            Product p = allProducts.get(i);

            if (p.getId() == id){
                return p;
            }
        }

        return null;
    }

     /**
      This will take me to the Modify Product screen to change product information.
      */
    public void onModifyProduct(ActionEvent actionEvent) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/ModifyProduct.fxml"));
            Parent root = loader.load();

            ModifyProductController MProController = loader.getController();
            MProController.sendProduct(productsTable.getSelectionModel().getSelectedItem());

            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Modify Product Form");
            stage.setScene(scene);
        }
        catch (NullPointerException e){
            System.out.println("Please select a product to modify!");


        }
    }

     /**
      This will delete a product if there are no associated parts or it will flag the user that there are associated parts when trying to delete a product.
      */
    public void onDeleteProduct(ActionEvent actionEvent) throws IOException{
        Product po = (Product) (productsTable.getSelectionModel().getSelectedItem());
        if (po.getAllAssociatedParts().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Do you want to delete this product?");
            alert.setHeaderText("Delete");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                ObservableList<Product> allProducts = Inventory.getAllProducts();
                if (po == null)
                    return;

                allProducts.remove(po);
            }

        }


        if (!po.getAllAssociatedParts().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.setContentText("This product has associated parts!");
            alert.showAndWait();
            System.out.println("TEST 1 DELETE PRODUCT");
        }



    }

     /**
       This will search the parts table using either a part name or ID.
      */

    public void onSearchPart(ActionEvent actionEvent) {
    String q = searchPartNameTxt.getText();

    ObservableList<Part> parts = searchPartName(q);

    if (parts.size() == 0) {
        try {
            int id = Integer.parseInt(q);
            Part p = getAPartWithID(id);
            if (p != null)
                parts.add(p);}
        catch (NumberFormatException e){}

    }
    partsTable.setItems(parts);
    searchPartNameTxt.setText("");
    }

    private ObservableList<Part> searchPartName(String partialName) {
        ObservableList<Part> namedParts = FXCollections.observableArrayList();

        ObservableList<Part> allParts = Inventory.getAllParts();

        for (Part p : allParts) {
            if (p.getName().contains(partialName)) {
                namedParts.add(p);
            }
        }
        return namedParts;
    }
    private Part getAPartWithID(int id){
        ObservableList<Part> allParts = Inventory.getAllParts();

        for (int i=0; i < allParts.size(); i++ ){
            Part p = allParts.get(i);

            if (p.getId() == id){
                return p;
            }
        }

        return null;
    }

     /**
      * This will take the user to the Add part screen to add a new part to inventory.
      */
    public void onAddPart(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Addpart.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Add Part Form");
        stage.setScene(scene);
        stage.show();
    }

     /**
      *  This will take the user to the modify part screen where they can change information.
      */
    public void onModifyPart(ActionEvent actionEvent) throws IOException {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/Modifypart.fxml"));
            Parent root = loader.load();

            ModifyPartController MPController = loader.getController();
            MPController.sendPart(partsTable.getSelectionModel().getSelectedItem());


            Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root); stage.setTitle("Modify Part Form");
            stage.setScene(scene);
        }
        catch (NullPointerException e){
            System.out.println("Please select a Part!");
        }

    }
     /**
      * This button will allow a user to delete a part from inventory.
      */
    public void onDeletePart(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Do you want to delete this part?");
        alert.setHeaderText("Delete");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {

            ObservableList<Part> allParts = Inventory.getAllParts();
            Part p = (Part) (partsTable.getSelectionModel().getSelectedItem());
            if (p == null)
                return;

            allParts.remove(p);
        }
    }
/**
 * This will take the user to the add product screen where they can enter information.
 */
    public void onAddProduct(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Addproduct.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Add Product Form");
        stage.setScene(scene);
        stage.show();
    }
/**
  When the user clicks this button the entire application will shut down. */
    public void onExit(ActionEvent actionEvent) {
        System.exit(0);
    }

     /**
      This is what the compiler will call to start up this page on the application. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am Initialized!");
        productsTable.setItems(Inventory.getAllProducts());
        productIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        partsTable.setItems(Inventory.getAllParts());
        partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

    }

}
