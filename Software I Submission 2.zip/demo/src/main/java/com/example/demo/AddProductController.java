package com.example.demo;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
    RUNTIME ERROR - A logical error that I experienced with this controller is I wasn't able to properly save my related parts table and when I would hit save my app would crash.
    After trying a few techniques I was able to get help from a Course Instructor, to identify where I was missing code that would relay the information between controllers so that I could modify it when necessary.
    I was able to fix the code by adding "product.getAllAssociatedParts().addAll(associatedParts);" under the code for my save button which ensured that I was able to pull all the associated parts for a product that I had added during the creation process.


    FUTURE ENHANCEMENT - to enhance this controller for the future, for new products to be added there should also be a place to put in anticipated analytical information about the expectations of the product.
    Such as projected sales, the overall costs of associated parts, and revenue made from the products.

    */
/**This is where you can add a product to the inventory class. */
public class AddProductController implements Initializable {

    public TextField searchPartNameTxt;
    public TextField ProductIDTxt;
    public TextField ProductNameTxt;
    public TextField ProdInvCountTxt;
    public TextField ProductPriceTxt;
    public TextField ProdMaxHoldTxt;
    public TextField ProdMinHoldTxt;
    public TableColumn partIDColumn;
    public TableColumn partNameColumn;
    public TableColumn partInvLevelColumn;
    public TableColumn partpriceColumn;
    public TableColumn ProductIDColumn;
    public TableColumn ProductNameColumn;
    public TableColumn ProdInvLevelColumn;
    public TableColumn ProdPriceColumn;
    public TableView relatedPartsTable;
    public TableView<Part> allPartsTable;




    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    private ObservableList<Part> bottomTableParts = FXCollections.observableArrayList();

    /**
     This will search for a name or ID.
     */
    public void onSearch(ActionEvent actionEvent) {
        String q = searchPartNameTxt.getText();

            ObservableList<Part> parts = searchPartName(q);

            if (parts.size() == 0) {
                try {
                    int id = Integer.parseInt(q);
                    Part p = getAPartWithID(id);
                    if (p != null)
                        parts.add(p);}
                catch (NumberFormatException e){}

            }
            allPartsTable.setItems(parts);
            searchPartNameTxt.setText("");
        }

        private ObservableList<Part> searchPartName(String partialName) {
            ObservableList<Part> namedParts = FXCollections.observableArrayList();

            ObservableList<Part> allParts = Inventory.getAllParts();

            for (Part p : allParts) {
                if (p.getName().contains(partialName)) {
                    namedParts.add(p);
                }
            }
            return namedParts;
        }
        private Part getAPartWithID(int id){
            ObservableList<Part> allParts = Inventory.getAllParts();

            for (int i=0; i < allParts.size(); i++ ){
                Part p = allParts.get(i);

                if (p.getId() == id){
                    return p;
                }
            }

            return null;
        }

    /**
     This will save the information to the application. */
    public void onSave(ActionEvent actionEvent) throws IOException {
        try {
            int id = Inventory.incrementProductID();
            String name = String.valueOf(ProductNameTxt.getText());
            double price = Double.parseDouble(ProductPriceTxt.getText());
            int stock = Integer.parseInt(ProdInvCountTxt.getText());
            int min = Integer.parseInt(ProdMinHoldTxt.getText());
            int max = Integer.parseInt(ProdMaxHoldTxt.getText());

            //bottomTableParts = Product.getAllAssociatedParts();
            bottomTableParts.addAll(associatedParts);


            if (stock>max){
                System.out.println("Stock must be lower than Maximum Inventory!");
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error");
                alert1.setHeaderText(null);
                alert1.setContentText("Stock must be lower than Maximum Inventory!");
                alert1.showAndWait();
                return;
            }

            if (stock<min){
                System.out.println("Stock must be higher than Minimum Inventory!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Stock must be higher than Minimum Inventory!");

                alert.showAndWait();
                return;
            }
            if (name.isBlank()) {
                System.out.println("Name Value is blank");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please enter valid values!");

                alert.showAndWait();

            }

            Product product = new Product(id, name, price, stock, min, max);
            product.getAllAssociatedParts().addAll(associatedParts);
            Inventory.addProduct(product);

            Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Inventory Management System");
            stage.setScene(scene);
            stage.show();
        }
        catch (NumberFormatException e){
            System.out.println("Please enter valid values!");
            System.out.println("Please enter number values in number fields!");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please enter number values in number fields!");

            alert.showAndWait();
        }
    }

/**
  This will add a part to the associated parts table. */

    public void onAdd(ActionEvent actionEvent) {
        Part SP = allPartsTable.getSelectionModel().getSelectedItem();
        if (SP == null)
            return;

        allParts.remove(SP);
        associatedParts.add(SP);
        relatedPartsTable.setItems(associatedParts);

    }
    /**
     This will remove a part associated to a product*/
    public void onRemoveAssociatedPart(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Do you want to remove this part?");
        alert.setHeaderText("Remove");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            Part SP = (Part) relatedPartsTable.getSelectionModel().getSelectedItem();
            if (SP == null)
                return;
            associatedParts.remove(SP);
            allParts.add(SP);
            relatedPartsTable.setItems(associatedParts);
        }
    }
    /**
     This will cancel the action and take the user back to the main screen*/
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();

    }

    /**
     This is what the compiler will call to start up this page on the application. */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        System.out.println("I am Initialized!");
        relatedPartsTable.setItems(associatedParts);
        allPartsTable.setItems(Inventory.getAllParts());
        partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partpriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        ProductIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        ProductNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ProdInvLevelColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        ProdPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}
