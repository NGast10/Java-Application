//Nyla Gaston
package com.example.demo;

import Model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application{
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Mainform.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        Part part1 = new InHouse(Inventory.incrementPartID(),"Brakes",15.00,10,1,20,111);
        Part part2 = new Outsourced(Inventory.incrementPartID(), "Wheel",11.000,16,1,20,"DealsonWheels");
        Part part3 = new InHouse(Inventory.incrementPartID(), "Seat",15.00,10,1,20,333);
        Inventory.addPart(part1);
        Inventory.addPart(part2);
        Inventory.addPart(part3);

       //* Product product1 = new Product(1000,"Giant Bike",299.99,5,1,10);
        Inventory.addProduct(new Product(Inventory.incrementProductID(),"Giant Bike",299.99,5,1,10));
        Inventory.addProduct(new Product(Inventory.incrementProductID(),"Tricycle",99.99,3,1,10));



        launch();

    }
}