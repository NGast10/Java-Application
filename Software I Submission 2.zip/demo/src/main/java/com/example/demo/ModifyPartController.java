package com.example.demo;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.RadioButton;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

 /**
    RUNTIME ERROR - I was getting an error where I was not able to navigate back to the home screen after clicking my save button. This was because my code for navigating back to the home screen was underneath my if statements.
    To fix this, I cut the navigation code and pasted it into the if statements under the "Save" actionevent. After testing, I realized that the if statements weren't being read and removing the navigation code from the bottom and putting it into the if statements resolved the issue.


    FUTURE ENHANCEMENT - An enhancement for this controller would be the ability to modify all parts of a specific group all at once.
    For example if all parts produced InHouse are to have their prices raised by 10%, instead of doing it one by one the app would have the functionality to update all InHouse parts price to 10% higher.
     */
/** This is where you will modify parts in inventory. */
public class ModifyPartController implements Initializable {

    public RadioButton Outsourced1;
    public RadioButton InHouse1;
    Stage stage;
    Parent scene;

    private static int selectedIndex;

    public TextField partIDTxt;
    public TextField partMaxTxt;
    public TextField partPriceTxt;
    public TextField partInvTxt;
    public TextField partNameTxt;
    public TextField partCompNameTxt;
    public TextField partMinTxt;
    public Label machinesCompanyLabel;
    public Label partIDLabel;
    public Label partNameLabel;
    public Label partStockLabel;
    public Label partPriceLabel;
    public Label partMaxLabel;
    public ToggleGroup sourceTG;
    public Label partMinLabel;
    public Label partSourceLabel;

     /**
      This will save the information to the application. */
    public void onSave(ActionEvent actionEvent) throws IOException {
        try{
             int id = Integer.parseInt(partIDTxt.getText());
             String name = String.valueOf(partNameTxt.getText());
            double price = Double.parseDouble(partPriceTxt.getText());
            int stock = Integer.parseInt(partInvTxt.getText());
            int min = Integer.parseInt(partMinTxt.getText());
            int max = Integer.parseInt(partMaxTxt.getText());


            if (stock>max){
                System.out.println("Stock must be lower than Maximum Inventory!");
                Alert alert1 = new Alert(Alert.AlertType.ERROR);
                alert1.setTitle("Error");
                alert1.setHeaderText(null);
                alert1.setContentText("Stock must be lower than Maximum Inventory!");
                alert1.showAndWait();
                return;
            }

            if (stock<min){
                System.out.println("Stock must be higher than Minimum Inventory!");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Stock must be higher than Minimum Inventory!");

                alert.showAndWait();
                return;
            }
            if (name.isBlank()) {
                System.out.println("Name Value is blank");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please enter valid values!");

                alert.showAndWait();
            }

        if (InHouse1.isSelected()) {
            System.out.println("Test 2");
            int machineID= Integer.parseInt(partCompNameTxt.getText());
            Part part = new InHouse(id,name,price,stock,min,max,machineID);
            Inventory.updatePart(selectedIndex,part);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/Mainform.fxml"));
            loader.load();

            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.setTitle("Inventory Management System");
            stage.show();
            //System.out.println("Test 2");
        }
        if (Outsourced1.isSelected()) {
            System.out.println("Test 3");
            String CompanyName = String.valueOf((partCompNameTxt.getText()));
            Part part = new Outsourced(id,name,price,stock,min,max,CompanyName);
            Inventory.updatePart(selectedIndex,part);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/demo/Mainform.fxml"));
            loader.load();

            stage = (Stage)((Button)actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.setTitle("Inventory Management System");
            //this.stage = null;
            stage.show();
            //System.out.println("Test 3");
        }
        }
        catch (NumberFormatException e){
            System.out.println("Please enter valid values!");
            System.out.println("Please enter number values in number fields!");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please enter number values in number fields!");

            alert.showAndWait();
        }
    }
     /**
      This will cancel the action and take the user back to the main screen*/
    public void onCancel(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/demo/Mainform.fxml"));
        Stage stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root); stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }
     /**
      This will let the application know whether it's an InHouse or Outsourced part. */
    public void onInhouse(ActionEvent actionEvent) {
        machinesCompanyLabel.setText("Machine ID");
    }
     /**
      This will let the application know whether it's an InHouse or Outsourced part. */
    public void onOutsourced(ActionEvent actionEvent) {
        machinesCompanyLabel.setText("Company Name");
    }

    public void sendPart(Part part)
    {
        selectedIndex = Inventory.getAllParts().indexOf(part);
        partIDTxt.setText(String.valueOf(part.getId()));
        partNameTxt.setText((part.getName()));
        partPriceTxt.setText(String.valueOf(part.getPrice()));
        partInvTxt.setText(String.valueOf(part.getStock()));
        partMaxTxt.setText(String.valueOf(part.getMax()));
        partMinTxt.setText(String.valueOf(part.getMin()));


        if (part instanceof  InHouse){
            partCompNameTxt.setText(String.valueOf(((InHouse) part).getMachineID()));
            InHouse1.setSelected(true);
            machinesCompanyLabel.setText("Machine ID");
        }


        if (part instanceof  Outsourced){
            partCompNameTxt.setText((((Outsourced) part).getCompanyName()));
            Outsourced1.setSelected(true);
            machinesCompanyLabel.setText("Company Name");
        }


    }

     /**
      This is what the compiler will call to start up this page on the application. */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am Initialized!");
    }
}
