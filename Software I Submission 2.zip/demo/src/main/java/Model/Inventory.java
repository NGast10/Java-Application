package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * RUNTIME ERROR - An error that I experienced with this page is I was not able to increment the IDs for parts and products.
 * I had the increment id code to return the unique ID as higher than the last one but it didn't start at 1.
 * To fix this I added a line of code that set the first ID to 1, then to increment after.
 *
 * FUTURE ENHANCEMENT - An enhancement for this page would be to include inventory of byproducts that have been made because of producing parts Inhouse.
 * For example if making a bottom bracket for a bike out of glass results in a lot of broken glass and shards, that byproduct could be sold to companies who use glass shards as sand for various products at a wholesale rate.
 * */
public class Inventory {

    /**
     * This is a full list of parts in inventory to be called on my different methods in the other screens. */
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();

    /**
     * This is a full list of products in inventory to be called on my different methods in the other screens.*/
    private static ObservableList<Product> allProducts =FXCollections.observableArrayList();

    /**
     * This method will set the ID 1. */
    private static int uniquePartID = 1;

    /**
     * This will increment the part ID that was previously set to 1.*/
    public static int incrementPartID(){
        return uniquePartID++;
    }

    /**
     * This method will set the product ID 1. */
    private static int uniqueProductID = 1000;
    /**
     * This will increment the product ID that was previously set to 1.*/
    public static int incrementProductID() {
        return uniqueProductID++;
    }





/**
 * This method will add a part to inventory.*/
    public static void addPart(Part part) {
        allParts.add(part);}
    /**
     * This method will add a product to inventory.*/
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**
      This method could be used to look up a part in the inventory. */
   public static Part lookupPart(int id)
   {
       for(Part part:allParts){
           if (part.getId() == id){
               return part;
           }
       }
       return null;
   }
    /**
     This method could be used to look up a product in the inventory. */
    public static Product lookupProduct(int id)
    {
        for (Product product:allProducts){
            if (product.getId() == id){
                return product;
            }
        }
        return null;
    }
    public static ObservableList<Part> lookupPart(String name)
    {
        for (Part part:allParts){
            if (part.getName() == name){
                return allParts;
            }
        }
        return null;
    }
    /**
     This method could be used to look up a part in the inventory. */
    public static ObservableList<Product> lookupProduct(String name)
    {
        for (Product product:allProducts){
            if (product.getName() == name){
                return allProducts;
            }
        }
        return null;
    }
    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index,selectedPart);
    }
    public static void updateProduct(int index, Product selectedProduct) {allProducts.set(index,selectedProduct);}

    public static boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }
    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }


    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }


}
