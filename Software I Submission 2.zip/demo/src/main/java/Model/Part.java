package Model;/**

/*Supplied class Part.java
        */

/**
 * AUTHOR: Nyla Gaston
 * RUNTIME ERROR - An error I experienced with this model is because it is abstract, it cannot be instantiated.
 * Therefore, I would have to pull from the Inventory,InHouse or Outsourced models for what I needed in order to not have any errors.
 * FUTURE ENHANCEMENT - To enhance this model in the future, it should include details about the creation of the part, such as which assmembly line makes it, how long it takes to make the part and more in-depth information about the part's creation.
 */
public abstract class Part {
    private int id; //must be a number
    private String name; //cannot be blank
    private double price; //must be a double
    private int stock; //must be a number
    private int min; //must be a number
    private int max; //must be a number
    public Part(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }
    //min <= stock <= max
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return the stock
     */
    public int getStock() {
        return stock;
    }

    /**
     * @param stock the stock to set
     */
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     * @return the min
     */
    public int getMin() {
        return min;
    }

    /**
     * @param min the min to set
     */
    public void setMin(int min) {
        this.min = min;
    }

    /**
     * @return the max
     */
    public int getMax() {
        return max;
    }

    /**
     * @param max the max to set
     */
    public void setMax(int max) {
        this.max = max;
    }

}
