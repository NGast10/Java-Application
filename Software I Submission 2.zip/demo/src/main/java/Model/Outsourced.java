package Model;

/**
 * RUNTIME ERROR - An error that I experienced with this page is I was not able to change the data type on the controller because I didn't correctly use the getCompanyName component from this model.
 * To fix this, I created if statements on the controllers which allowed me to remove the error from this model as it was correctly being called on the controller.
 *
 * FUTURE ENHANCEMENT - To enhance this model in the future, there should be an option to view contract data about parts that are being Outsourced.
 * This would tell the user when the contract ends and allow them to see contract details involving part prices and cancellation policies should another company have a better price for different parts.
 * */
public class Outsourced extends Part {
    private String CompanyName;
    public Outsourced(int id, String name, double price, int stock, int min, int max, String CompanyName) {
        super(id, name, price, stock, min, max);
        this.CompanyName = CompanyName;
    }
    /**
     * @return the CompanyName
     */
    public String getCompanyName() {
        return CompanyName;
    }
    /**
     * @param CompanyName the CompanyName to set
     */
    public void setCompanyName(String CompanyName) {
        this.CompanyName = CompanyName;
    }
}
