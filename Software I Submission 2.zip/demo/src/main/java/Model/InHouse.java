package Model;

/**
 * RUNTIME ERROR - An error that I experienced with this page is initially the max was showing up as the min when it was ran and vice versa, I would always have to change the max and min to the correct values before saving again.
 * To fix this, I had to come to this model where I realized that I had switched the max and min placements when writing out this code and moving them to match the placements they have on the Part model fixed that issue.

 * FUTURE ENHANCEMENT - To enhance this model for the future, it would be incredibly helpful to show information about the production process of InHouse parts.
 * For example, that could answer the following questions: how long does a part take to make, how many people are required to make a part, how many parts are to be made in a day/week/month, and how many parts are defective after being made?
 *
 * */
public class InHouse extends Part {
    private int machineID;
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineID) {
        super(id, name, price, stock, min, max);
        this.machineID = machineID;
    }

    /**
     * @return the machineID
     */
    public int getMachineID() {
        return machineID;
    }
    /**
     * @param machineID the machineID to set
     */
    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }

}
