package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * RUNTIME ERROR - An error I experienced with this model was I was incorrectly calling the get() for the attributes that go into the Add and Modoify Product controllers.
 * To fix this, I had to ensure that I was using the correct name for each attribute as nothing was returning before, once that was fixed I was able to pull the necessary information for my controllers.
 * FUTURE ENHANCEMENT - To enhance this model in the future, it should include performance information fields for products.
 * For example, there should be a place where performance level can be input for each product from customer reviews or from product testing.
 */
public class Product {
    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    public void addAssociatedPart(Part part)
    {allParts.add(part);}
    public ObservableList<Part> deleteAssociatedPart (Part selectedAssociatedPart)
    {allParts.remove(selectedAssociatedPart);
    return allParts;}
    public ObservableList<Part> getAllAssociatedParts()
    {return allParts;}
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
    /**
     * @param id the id to set
     */
    public void setId(int id) {this.id = id;}
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {this.name = name;}
    /**
     * @return the price
     */
    public double getPrice() {return price;}
    /**
     * @param price the price to set
     */
    public void setPrice(double price) {this.price = price;}
    /**
     * @return the stock
     */
    public int getStock() {
        return stock;
    }
    /**
     * @param stock the stock to set
     */
    public void setStock(int stock) {this.stock = stock;}

    /**
     * @return the min
     */
    public int getMin() {
        return min;
    }
    /**
     * @param min the min to set
     */
    public void setMin(int min) {this.min = min;}
    /**
     * @return the max
     */
    public int getMax() {
        return max;
    }
    /**
     * @param max the max to set
     */
    public void setMax(int max) {this.max = max;}
























}






